import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-edit-user',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './edit-user.component.html',
  styleUrl: './edit-user.component.css'
})
export class EditUserComponent {
  editedUser:any = []; 
  userId:any; 
  name:any;
  role:any;
  email:any;
  
  constructor(private userService: UserService, private route: ActivatedRoute) {}
  
 async ngOnInit() {
    await this.route.params.subscribe(params=>{
      this.userId = params['id'];
      console.log(this.userId)
    })
    const data = this.userService.getUsers();
    this.editedUser = data.filter(x=>x.id == this.userId)
    console.log(this.editedUser);
    this.name = this.editedUser[0].name;
    this.role = this.editedUser[0].role;
    this.email = this.editedUser[0].email;
  }
  saveChanges(){
    let obj = {
      id:this.userId,
      name:this.name,
      role:this.role,
      email:this.email
    };
    const res = this.userService.editUser(obj);
    if(res){
      alert("user updated..!")
    }else{
      alert("something went wrong..!")
    }
  }
}

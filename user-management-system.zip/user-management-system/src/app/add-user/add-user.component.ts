import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-user',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.css',
})
export class AddUserComponent {
  constructor(private userService:UserService){

  }
  newUser = {
    name: '',
    email: '',
    role: '',
  };

  addUser() {
    this.userService.addUser(this.newUser);
    const data = this.userService.getUsers();
    console.log(data);
  }
}

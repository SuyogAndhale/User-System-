import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserService } from '../user.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule,NgxPaginationModule],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent {
  title:any = "User List";
  users:any;
  p: number = 1;

  constructor(private userService: UserService) {
    this.users = this.userService.getUsers();
  }
  deleteUser(user:any){
    this.userService.deleteUser(user);
  }
  handlePageChange(event: any) {
    this.p = event;
  }
}

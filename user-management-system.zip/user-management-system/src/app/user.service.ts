import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }
  private users = [
    { id: 1, name: 'suyog', email: 'suyog@gmail.com', role: 'Admin' },
    { id: 2, name: 'sonu', email: 'sonuandhale@gmail.com', role: 'User' },
    { id: 3, name: 'Ravi', email: 'lemon@gmail.com', role: 'subadmin' },
    { id: 4, name: 'sonu', email: 'sonuandhale@gmail.com', role: 'User' },
    { id: 5, name: 'sonu', email: 'sonuandhale@gmail.com', role: 'User' },
    { id: 6, name: 'sonu', email: 'sonuandhale@gmail.com', role: 'User' },
    { id: 7, name: 'sonu', email: 'sonuandhale@gmail.com', role: 'User' },
    { id: 8, name: 'sonu', email: 'sonuandhale@gmail.com', role: 'User' },


  ];

  getUsers() {
    return this.users;
  }

  addUser(newUser: any) {
    newUser.id = this.users.length + 1;
    this.users.push(newUser);
  }

  editUser(updatedUser: any):boolean {
    const index = this.users.findIndex(user => user.id === parseInt(updatedUser.id));
    if (index !== -1) {
      this.users[index] = updatedUser;
      return true
    }else{
      return false
    }
  }

  deleteUser(userId: number) {
    const index = this.users.findIndex(x => x.id === userId);
    if (index > -1) {
      this.users.splice(index, 1);
   }
  }
}
